# coding=utf-8
from PyQt4.QtGui import *
from PyQt4.QtCore import *
from PyQt4 import QtGui, QtCore
import urllib2
import urllib
import re
import sys
import cookielib
import gc
def down_load():
    url = 'http://phoenix.stu.edu.cn/login.aspx'
    request = urllib2.Request(url)
    response = urllib2.urlopen(request)
    content = response.read()

    pattern = re.compile('../WallPaper(.*?).jpg', re.S)
    items = re.findall(pattern, content)

    for item in items:
        string_webline = str('http://phoenix.stu.edu.cn/WallPaper') + str(item) + str('.jpg')
    return string_webline
url = down_load()

class ShapeWidget(QWidget):
    def __init__(self,parent=None):
        version = 3.00
        ############################实现了稍微动态##########################################
        super(ShapeWidget,self).__init__(parent)
        pix=QPixmap("res/5s.png","0",Qt.AvoidDither|Qt.ThresholdDither|Qt.ThresholdAlphaDither)
        self.resize(310,645)
        self.setMask(pix.mask())
        self.dragPosition=None
        self.UI()
    def login_STU(self):
        hosturl = 'http://a.stu.edu.cn'
        url = 'http://a.stu.edu.cn/ac_portal/login.php'
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36',
            'Referer': 'http://a.stu.edu.cn/ac_portal/20160808100633/pc.html?template=20160808100633&tabs=pwd&vlanid=0&url=',
            'Host': 'a.stu.edu.cn',
            'Origin': 'http://a.stu.edu.cn',
            }
        postData = {'opr': 'pwdLogin',
                    'userName': self.leName.text(),
                    'pwd': self.leName2.text(),
                    'rememberPwd': '0'}
        postData = urllib.urlencode(postData)
        request = urllib2.Request(url, postData, headers)
        response = urllib2.urlopen(request)
        text = response.read()
        ##############################成功登陆############################
        pattern = re.compile('.*?success.*?:(.*?),.*?', re.S)
        items = re.findall(pattern, text)
        print 'hello '
        print items[0]
        print 'hi'
        self.leName.hide()
        self.leName2.hide()
        self.show_logout()
        ############################退出登录###################################
    def logout_STU(self):
        url = 'http://a.stu.edu.cn/ac_portal/login.php'
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36',
            'Host': 'a.stu.edu.cn',
            'Origin': 'http://a.stu.edu.cn',
            }
        postData = {'opr': 'logout'}
        postData = urllib.urlencode(postData)
        request = urllib2.Request(url, postData, headers)
        response = urllib2.urlopen(request)
        text = response.read()
        self.show_login()
        self.exit_login.hide()


        ##################### 覆盖函数 #######################################
    def mousePressEvent(self,event):
        if event.button()==Qt.LeftButton:
            self.dragPosition=event.globalPos()-self.frameGeometry().topLeft()
            event.accept()
        if event.button()==Qt.RightButton:
            self.close()
    def mouseMoveEvent(self,event):
        if event.buttons() & Qt.LeftButton:
            self.move(event.globalPos()-self.dragPosition)
            event.accept()
    def paintEvent(self,event):
        painter=QPainter(self)
        painter.drawPixmap(0,0,QPixmap("124.jpg"))
        pen = QtGui.QPen(QtGui.QColor(30, 30, 30, 255*0.7 ), 1)
        pen.setWidth(4)
        painter.setPen(pen)
        painter.drawRoundedRect(QtCore.QRect(0,0,310,644),10, 10)
    def UI(self):
         self.judge()
    def show_logout(self):
        self.exit_login = QtGui.QPushButton(u'注销登陆', self)
        self.exit_login.setStyleSheet(
            '''color:black;background:white;font-size:18px;font-family:Roman times;border-radius:12px;''')
        self.exit_login.setGeometry(45, 470, 200, 40)
        self.exit_login.show()
        #####################################按钮作用##############################
        self.connect(self.exit_login, QtCore.SIGNAL('clicked()'),
                     self.logout_STU)
     #   self.connect(loginButton, QtCore.SIGNAL('clicked()'),
      #               self.login_STU)
    def show_login(self):

         ######################设置输入框##############################
        self.leName = QtGui.QLineEdit(self)
        self.leName.setStyleSheet(
            '''color:black;background:white;font-size:15px;font-family:Roman times;border-radius:12px;''')
        self.leName.setPlaceholderText(u'校园网账号')
        self.leName.setGeometry(45, 245, 220, 40)
        self.leName.show()

        self.leName2 = QtGui.QLineEdit(self)
        self.leName2.setStyleSheet(
            '''color:black;background:white;font-size:13px;font-family:Roman times;border-radius:12px;''')
        self.leName2.setPlaceholderText(u'密码/Enter登陆')
        self.leName2.setEchoMode(QtGui.QLineEdit.Password)
        self.leName2.returnPressed.connect(self.login_STU)
        self.leName.returnPressed.connect(self.login_STU)
        self.leName2.setGeometry(45, 305, 220, 40)
        self.leName2.show()
        #############################设置登陆按钮和退出按钮######################
       # loginButton = QtGui.QPushButton(u'登陆', self)
       # loginButton.setStyleSheet(
       #     '''color:black;background:white;font-size:18px;font-family:Roman times;border-radius:12px;''')
      #  loginButton.setGeometry(45, 355, 200, 40)
       # self.leName2.returnPressed.connect(self.login_STU)
    def judge(self):
        url = 'http://a.stu.edu.cn/ac_portal/userflux'
        headers = {}
        postData = {}
        postData = urllib.urlencode(postData)
        request = urllib2.Request(url, postData, headers)
        response = urllib2.urlopen(request)
        self.text = response.read()
        if (len(self.text)==182):
            self.show_login()
        else:
            self.show_logout()
    def check(self):
        pattern = re.compile('.*?<td>用户名称：</td> <td>(.*?)</td>.*?<td>当天流量：</td> <td>(.*?)M</td>.*?', re.S)
        items = re.findall(pattern, self.text)
        for item in items:
            s = re.findall("\d+", item[1])[0]
            print item[0]
            print int(s)
class GetImage():
    reload(sys)
    sys.setdefaultencoding('utf8')
    def get_file(self, url):
        try:
            cj = cookielib.LWPCookieJar()
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
            urllib2.install_opener(opener)

            req = urllib2.Request(url)
            operate = opener.open(req)
            data = operate.read()
            return data
        except BaseException, e:
            print e
            return None
    def save_file(self, file_name, data):
        if data == None:
            return

        file = open(file_name, "wb")
        file.write(data)
        file.flush()
        file.close()

    def save_png_file(self, filename, url):
        self.save_file(filename, self.get_file(url))
########################################回收机构######################################################
gc.set_debug(gc.DEBUG_STATS|gc.DEBUG_LEAK)
h1 = GetImage()
h1.save_file('124.jpg', h1.get_file(url))
##########################################删除H1######################################################
del h1
app=QApplication(sys.argv)
form=ShapeWidget()
form.setStyleSheet( '''border:2px groove black;border-radius:10px;padding:10px 5px;background-position: center;''')
form.show()
app.exec_()
